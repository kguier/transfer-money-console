﻿namespace MoneyTransfer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Simulation sim = new Simulation();
            sim.RunSimulation();
        }
    }
}