﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyTransfer
{
    internal class Wallet
    {
        public int money;

        public Wallet(int money)
        {
            //TODO 1: Assign the value of the 'money' parameter to the 'money' instance variable. One line.
            this.money = money;
        }
    }
}
